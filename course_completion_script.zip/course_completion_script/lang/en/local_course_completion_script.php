<?php
// Este arquivo está intencionalmente vazio, mas é necessário para evitar erros de instalação.
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Course Completion Script Plugin';
