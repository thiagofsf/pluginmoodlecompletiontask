<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_course_completion_script';
$plugin->version = 2024070400;
$plugin->requires = 2020110900; // Requer o Moodle 3.10 ou superior
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';

?>